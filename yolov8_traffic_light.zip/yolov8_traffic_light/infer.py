from ultralytics import YOLO
import os

dir_path = r'ultralytics\assets'

model = YOLO('yolov8n.pt')

img_list = os.listdir(dir_path)
for img_name in img_list:
    model.predict(os.path.join(dir_path, img_name), save=True, show=False)

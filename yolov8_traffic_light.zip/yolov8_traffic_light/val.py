from ultralytics import YOLO
import torch

# model = YOLO('path/to/your/best.pt')
# results = model.val(data='ultralytics/datasets/coco.yaml', batch=1)
print(torch.load('yolov8n-cls.pt'))
# results.box.map
# results.box.map50
